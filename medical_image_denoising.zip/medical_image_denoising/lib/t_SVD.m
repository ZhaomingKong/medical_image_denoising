function [im2] = t_SVD(im1,Percentage_noise,sigma,modified)

%% denoise with mex function
if(Percentage_noise<=5)
    ps = 4; maxK = 30;tau = 1.8;
elseif(Percentage_noise<9)
    ps = 5; maxK = 80;tau = 2;
else
    ps = 5; maxK = 80;tau = 2.4;
end
SR = ps; N_step = ps - 1;

[H,W,D] = size(im1);
info1 = [H,W,D];
info2 = [ps(1),N_step,SR,maxK];
info3 = [tau,modified,sigma];
im2 = medical_denoising_t_SVD(double(im1),int32(info1),int32(info2), single(info3));im2 = mat_ten(im2,1,size(im1));
end

