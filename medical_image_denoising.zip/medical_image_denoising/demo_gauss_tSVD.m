test_data         = 1;
if(test_data == 0)
    phantom           = 't1_icbm_normal_1mm_pn0_rf0.rawb'; % name of the phantom raw data
elseif(test_data == 1)
    phantom       = 't2_icbm_normal_1mm_pn0_rf0.rawb';
elseif(test_data == 2)
    phantom       = 'pd_icbm_normal_1mm_pn0_rf0.rawb';
end

% fid = fopen(phantom);
% y = reshape(fread(fid,181*217*181),[181 217 181]);
% fclose(fid);
disp(phantom);

addpath('lib');

for percentNoise = 1:2:19
% sigma             = 15;      % noise standard deviation given as percentage of the
                             % maximum intensity of the signal, must be in [0,100]
crop_phantom      = 1;       % experiment on smaller phantom
test_mode         = 0;       % choose test algorithm.
modified          = 1;
distribution      = 'Gauss'; % noise distribution
                             %  'Gauss' --> Gaussian distribution
variable_noise    = 0;       % enable spatially varying noise
% tau = 2.2;maxK = 80;
% ps = [5,5,5];N_step = max(ps)                                                                                                                                                                  -1;SR = max(ps);
% disp([num2str(percentNoise),' maxK = ',num2str(maxK),' ps = ',num2str(ps),' N_step = ',num2str(N_step)]);
%% open and add noise
fid = fopen(phantom);
y = reshape(fread(fid,181*217*181),[181 217 181]);
fclose(fid);
if crop_phantom
     y = y(80:130,80:130,50:100);
end

max_y = max(y(:));y = y/max_y;
ind = y>(10/max_y);
% generate noisy phantom
randn('seed',0);
rand('seed',0);
sigma = percentNoise*max(y(:))/100;
disp(['Uniform ',distribution,' noise ',num2str(sigma),' ',num2str(sigma/max(y(:)))])
map = ones(size(y));

eta = sigma*map;
if strcmpi(distribution,'Rice')
    z = sqrt( (y+eta.*randn(size(y))).^2 + (eta.*randn(size(y))).^2 );
else
    z = y + eta.*randn(size(y));
end



%% denoise using t_SVD
tic
if(test_mode == 1)
    disp('denoise using local t_SVD');
    [im2] = t_SVD(z,percentNoise,sigma,modified);
else
    disp('Using global tSVD for gauss noise');
    [im2] = global_tSVD(z,percentNoise,sigma,modified);
end
time1 = toc;
psnr_t = 10*log10(1/mean((y(ind)-im2(ind)).^2));
im_ssim = ssim_index3d(y*255,im2*255,[1 1 1],ind);
disp([num2str(time1),' ',num2str(psnr_t),' ',num2str(im_ssim)]);


end
